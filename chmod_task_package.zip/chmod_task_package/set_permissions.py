#!/usr/bin/env python3
"""
Set Unix-style permissions on a file or folder from Python.

Usage:
  python3 set_permissions.py <path> [--mode 775] [--recursive]

Examples:
  python3 set_permissions.py example.py
  python3 set_permissions.py my_folder --mode 775 --recursive

Notes:
- '775' == rwxrwxr-x  (owner: rwx, group: rwx, others: r-x)
- Works on macOS and Linux. On Windows, chmod support is limited.
"""
import os, argparse, stat, sys

def to_symbolic(mode: int) -> str:
    return stat.filemode(mode)

def to_octal_str(mode: int) -> str:
    return oct(mode & 0o777)[2:]

def chmod_path(path: str, mode_int: int, recursive: bool=False) -> int:
    changed = 0
    if os.path.isfile(path):
        os.chmod(path, mode_int)
        changed += 1
    elif os.path.isdir(path):
        if recursive:
            for root, dirs, files in os.walk(path):
                for name in dirs + files:
                    p = os.path.join(root, name)
                    try:
                        os.chmod(p, mode_int)
                        changed += 1
                    except PermissionError as e:
                        print(f"[WARN] Skipped {p}: {e}")
        else:
            os.chmod(path, mode_int)
            changed += 1
    else:
        raise FileNotFoundError(f"No such file or directory: {path}")
    return changed

def main():
    parser = argparse.ArgumentParser(description="Set Unix permissions (chmod) from Python.")
    parser.add_argument("path", help="File or directory to change permissions for")
    parser.add_argument("--mode", default="775", help="Octal permission (default: 775)")
    parser.add_argument("--recursive", action="store_true", help="Recurse into directories")
    args = parser.parse_args()

    # Validate octal mode
    try:
        mode_int = int(args.mode, 8)
    except ValueError:
        print(f"Invalid mode '{args.mode}'. Use an octal like 775 or 644.")
        sys.exit(2)

    target = args.path
    if not os.path.exists(target):
        print(f"Error: {target} does not exist.")
        sys.exit(1)

    before = os.stat(target).st_mode
    print(f"Before: symbolic={to_symbolic(before)} numeric={to_octal_str(before)}")    

    try:
        changed = chmod_path(target, mode_int, recursive=args.recursive)
    except Exception as e:
        print(f"Failed to chmod: {e}")
        sys.exit(1)

    after = os.stat(target).st_mode
    print(f"After:  symbolic={to_symbolic(after)} numeric={to_octal_str(after)}")
    print(f"Changed permissions on {changed} item(s). Done.")

if __name__ == "__main__":
    main()
