print("Hello from example.py!")
