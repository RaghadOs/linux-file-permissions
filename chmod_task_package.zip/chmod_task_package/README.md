# File Permissions + Python `chmod` Task

This mini-project helps you understand Unix file permissions and apply them programmatically from Python.

## What you will submit
- `permissions_flowchart.png` (the flowchart image)
- `example.py` (a sample file to change)
- `set_permissions.py` (the Python script that applies `chmod`)
- (Optional) a screenshot of your terminal showing `Before` and `After` outputs, or `ls -l`

## Quick Start (macOS/Linux)
```bash
cd chmod_task
python3 set_permissions.py example.py --mode 775
# Verify in shell:
ls -l example.py
# Expected: -rwxrwxr-x ...
```

## How it works
- `775` in octal is `rwxrwxr-x`:
  - owner: read+write+execute
  - group: read+write+execute
  - others: read+execute
- The script prints the **Before** and **After** permissions in both symbolic and numeric forms.
- Use `--recursive` to apply the same mode to every file under a folder.

## Extra
To change a directory and everything inside it:
```bash
python3 set_permissions.py my_folder --mode 775 --recursive
```
